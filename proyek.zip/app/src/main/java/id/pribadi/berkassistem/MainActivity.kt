package id.pribadi.berkassistem

import android.app.Activity
import android.app.AlertDialog
import android.content.ClipData
import android.content.ClipboardManager
import android.content.Context
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import android.widget.Toast
import rikka.shizuku.Shizuku
import java.io.File
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Aksi(
        val judul: String,
        val info: String,
        val pratinjau: () -> Unit,
        val hapus: (() -> Unit)?
    )

    private val daftarAksi = listOf(
        Aksi(
            "1. Analisis penyimpanan",
            "Hanya membaca, tidak menghapus apa pun. Menampilkan aplikasi dengan data dan cache terbesar serta folder terbesar.",
            { analisis() },
            null
        ),
        Aksi(
            "2. Bersihkan cache semua aplikasi",
            "Hanya cache (berkas sementara). Data, login, dan berkas pribadi tidak disentuh. Log menampilkan cache tiap aplikasi sebelum dan sesudah.",
            { pratinjauCacheSemua() },
            { hapusCacheSemua() }
        ),
        Aksi(
            "3. Bersihkan cache eksternal",
            "Mengosongkan folder cache di /sdcard/Android/data/<aplikasi>/cache. Log menampilkan tiap folder dan berkas di dalamnya.",
            { pratinjauCacheEksternal() },
            { hapusCacheEksternal() }
        ),
        Aksi(
            "4. Bersihkan log MIUI",
            "Mengosongkan /sdcard/MIUI/debug_log dan buffer logcat (buffer logcat ada di memori, jadi tidak menambah ruang).",
            { pratinjauLog() },
            { hapusLog() }
        ),
        Aksi(
            "5. Reset dexopt",
            "Mengembalikan hasil kompilasi aplikasi ke bawaan. Bisa beberapa menit, dan aplikasi mungkin terasa lebih lambat sampai sistem mengoptimalkan ulang. Tidak menghapus berkas pribadi.",
            { pratinjauDexopt() },
            { hapusDexopt() }
        )
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val tombolAksi = mutableListOf<Button>()
    private val buffer = StringBuilder()
    private val jam = SimpleDateFormat("HH:mm:ss", Locale.US)
    private val namaLog =
        "BerkasSistem-log-" + SimpleDateFormat("yyyyMMdd-HHmmss", Locale.US).format(Date()) + ".txt"

    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var bebasView: TextView
    private lateinit var log: TextView

    private val listenerBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { segarkan() } }
    private val listenerMati = Shizuku.OnBinderDeadListener { runOnUiThread { segarkan() } }
    private val listenerIzin =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { segarkan() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(32), pad, pad)
        }

        status = TextView(this).apply { textSize = 16f }
        bebasView = TextView(this).apply { textSize = 14f }
        root.addView(status)
        root.addView(bebasView)

        root.addView(Button(this).apply {
            text = "Buka Shizuku"
            setOnClickListener { bukaShizuku() }
        })
        root.addView(Button(this).apply {
            text = "Beri izin Shizuku"
            setOnClickListener { mintaIzin() }
        })

        daftarAksi.forEach { aksi ->
            val tombol = Button(this).apply {
                text = aksi.judul
                setOnClickListener { klik(aksi) }
            }
            tombolAksi += tombol
            root.addView(tombol)
            root.addView(TextView(this).apply {
                text = aksi.info
                textSize = 12f
            })
        }

        root.addView(Button(this).apply {
            text = "Salin seluruh log"
            setOnClickListener { salinLog() }
        })
        root.addView(TextView(this).apply {
            text = "Log lengkap juga disimpan otomatis ke Download/" + namaLog
            textSize = 12f
        })

        log = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(log)

        scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        Shizuku.addBinderReceivedListenerSticky(listenerBinder)
        Shizuku.addBinderDeadListener(listenerMati)
        Shizuku.addRequestPermissionResultListener(listenerIzin)
        segarkan()
    }

    override fun onResume() {
        super.onResume()
        segarkan()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(listenerBinder)
        Shizuku.removeBinderDeadListener(listenerMati)
        Shizuku.removeRequestPermissionResultListener(listenerIzin)
        executor.shutdown()
        super.onDestroy()
    }

    // ---------- util ----------

    private fun dp(nilai: Int): Int = (nilai * resources.displayMetrics.density).toInt()

    private fun fmt(byte: Long): String = Formatter.formatFileSize(this, byte)

    private fun bebasByte(): Long =
        StatFs(Environment.getDataDirectory().path).availableBytes

    private fun sh(perintah: String): Shell.Hasil = try {
        Shell.jalankan(perintah)
    } catch (e: Throwable) {
        val sebab = e.cause ?: e
        Shell.Hasil(-1, "", sebab.javaClass.simpleName + ": " + sebab.message)
    }

    /** Tampil di layar dan masuk ke berkas log. */
    private fun catat(teks: String) {
        val baris = synchronized(buffer) {
            val b = if (teks.isEmpty()) "" else jam.format(Date()) + "  " + teks
            buffer.append(b).append('\n')
            b
        }
        runOnUiThread {
            log.append(baris + "\n")
            scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
        }
    }

    /** Hanya masuk ke berkas log (rincian panjang), tidak ditampilkan di layar. */
    private fun catatFile(teks: String) {
        synchronized(buffer) { buffer.append("          ").append(teks).append('\n') }
    }

    private fun segarkan() {
        status.text = try {
            when {
                !Shizuku.pingBinder() -> "Shizuku: belum berjalan"
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                    "Shizuku: berjalan, izin belum diberikan"
                else -> "Shizuku: siap"
            }
        } catch (e: Throwable) {
            "Shizuku: tidak tersedia"
        }
        bebasView.text = "Ruang bebas: " + fmt(bebasByte())
    }

    private fun siap(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun bukaShizuku() {
        val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (intent == null) {
            catat("Aplikasi Shizuku belum terpasang. Pasang dulu dari GitHub atau Play Store.")
        } else {
            startActivity(intent)
        }
    }

    private fun mintaIzin() {
        try {
            if (!Shizuku.pingBinder()) {
                catat("Shizuku belum berjalan. Buka aplikasi Shizuku lalu mulai lewat Wireless debugging.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                catat("Izin sudah diberikan.")
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                catat("Izin ditolak permanen. Aktifkan lewat aplikasi Shizuku, menu izin aplikasi.")
                return
            }
            Shizuku.requestPermission(100)
        } catch (e: Throwable) {
            catat("Gagal meminta izin: " + e.message)
        }
    }

    private fun salinLog() {
        val isi = synchronized(buffer) { buffer.toString() }
        val cm = getSystemService(Context.CLIPBOARD_SERVICE) as ClipboardManager
        cm.setPrimaryClip(ClipData.newPlainText("log", isi))
        Toast.makeText(this, "Log disalin", Toast.LENGTH_SHORT).show()
    }

    private fun simpanLog() {
        try {
            val dir = getExternalFilesDir(null) ?: filesDir
            val sementara = File(dir, "log.tmp")
            val isi = synchronized(buffer) { buffer.toString() }
            sementara.writeText(isi)
            val tujuan = "/sdcard/Download/" + namaLog
            val r = sh("cp '" + sementara.absolutePath + "' '" + tujuan + "'")
            if (r.kode == 0) {
                catat("Log lengkap disimpan: " + tujuan)
            } else {
                catat("Log tidak bisa disimpan ke Download (" + r.err + "). Pakai tombol Salin seluruh log.")
            }
        } catch (e: Throwable) {
            catat("Log tidak bisa disimpan: " + e.message)
        }
    }

    // ---------- alur tombol ----------

    private fun klik(aksi: Aksi) {
        if (!siap()) {
            catat("Shizuku belum siap. Pastikan Shizuku berjalan dan izin sudah diberikan.")
            return
        }
        val hapus = aksi.hapus
        if (hapus == null) {
            kerjakan(aksi.judul, aksi.pratinjau)
            return
        }
        AlertDialog.Builder(this)
            .setTitle(aksi.judul)
            .setMessage(aksi.info + "\n\n\"Pratinjau saja\" hanya menampilkan apa yang akan dihapus, tanpa menghapus.")
            .setPositiveButton("Hapus") { _, _ -> kerjakan(aksi.judul, hapus) }
            .setNeutralButton("Pratinjau saja") { _, _ ->
                kerjakan("Pratinjau (tidak ada yang dihapus): " + aksi.judul, aksi.pratinjau)
            }
            .setNegativeButton("Batal", null)
            .show()
    }

    private fun aturSibuk(sibuk: Boolean) {
        tombolAksi.forEach { it.isEnabled = !sibuk }
    }

    private fun kerjakan(judul: String, kerja: () -> Unit) {
        aturSibuk(true)
        catat("")
        catat("> " + judul)
        executor.execute {
            val sebelum = bebasByte()
            try {
                kerja()
            } catch (e: Throwable) {
                catat("GAGAL: " + e.javaClass.simpleName + ": " + e.message)
            }
            catat("Ruang bebas: " + fmt(sebelum) + " -> " + fmt(bebasByte()))
            simpanLog()
            runOnUiThread {
                aturSibuk(false)
                segarkan()
            }
        }
    }

    // ---------- statistik aplikasi ----------

    private fun ambilPaket(): List<Stat.Paket> {
        sh("appops set " + packageName + " GET_USAGE_STATS allow")
        val p = try {
            Stat.ambil(this)
        } catch (e: Throwable) {
            catat("Statistik aplikasi tidak terbaca: " + e.javaClass.simpleName + ": " + e.message)
            emptyList()
        }
        if (p.isEmpty()) catat("Tidak ada data aplikasi yang terbaca.")
        return p
    }

    private fun tampil(urut: List<Stat.Paket>, batas: Int, nilai: (Stat.Paket) -> Long) {
        var i = 0
        for (x in urut) {
            val n = nilai(x)
            if (n <= 0) continue
            val baris = fmt(n).padStart(10) + "  " + x.label + " (" + x.nama + ")"
            if (i < batas) catat(baris) else catatFile(baris)
            i++
        }
        if (i > batas) catat("... " + (i - batas) + " aplikasi lain ada di berkas log")
    }

    // ---------- 1. analisis ----------

    private fun analisis() {
        val p = ambilPaket()
        if (p.isNotEmpty()) {
            catat("Aplikasi terbaca: " + p.size)
            catat("Kode aplikasi total: " + fmt(p.sumOf { it.app }))
            catat("Data aplikasi total (di luar cache): " + fmt(p.sumOf { it.data - it.cache }))
            catat("Cache aplikasi total: " + fmt(p.sumOf { it.cache }))
            catat("-- Data terbesar (di luar cache) --")
            tampil(p.sortedByDescending { it.data - it.cache }, 15) { it.data - it.cache }
            catat("-- Cache terbesar --")
            tampil(p.sortedByDescending { it.cache }, 15) { it.cache }
        }
        catat("-- Folder Android/data terbesar --")
        val d = sh("du -sm /sdcard/Android/data/* 2>/dev/null | sort -rn | head -n 15")
        d.out.lines().forEach { if (it.isNotBlank()) catat(it) }
        catat("-- Folder tersembunyi di /sdcard (MB) --")
        val h = sh("du -sm /sdcard/.[!.]* 2>/dev/null | sort -rn | head -n 10")
        h.out.lines().forEach { if (it.isNotBlank()) catat(it) }
        catat("-- Sisa ruang /data --")
        catat(sh("df -h /data | tail -n 1").out)
    }

    // ---------- 2. cache semua aplikasi ----------

    private fun pratinjauCacheSemua() {
        val p = ambilPaket()
        if (p.isEmpty()) return
        val ada = p.filter { it.cache > 0 }.sortedByDescending { it.cache }
        catat("Cache yang AKAN dihapus: " + fmt(ada.sumOf { it.cache }) + " dari " + ada.size + " aplikasi")
        catat("(Hanya cache. Data, login, dan berkas pribadi tidak disentuh.)")
        tampil(ada, 30) { it.cache }
    }

    private fun hapusCacheSemua() {
        val sebelum = ambilPaket()
        if (sebelum.isEmpty()) return
        catat("Total cache sebelum: " + fmt(sebelum.sumOf { it.cache }))
        val r = sh("pm trim-caches 999G")
        catat("pm trim-caches selesai, kode " + r.kode + (if (r.err.isNotEmpty()) " [" + r.err + "]" else ""))
        val sesudah = ambilPaket().associateBy { it.nama }
        val turun = sebelum
            .map { Pair(it, it.cache - (sesudah[it.nama]?.cache ?: it.cache)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
        catat("Cache yang benar-benar terhapus: " + fmt(turun.sumOf { it.second }) + " dari " + turun.size + " aplikasi")
        var i = 0
        for (h in turun) {
            val baris = fmt(h.second).padStart(10) + "  " + h.first.label + " (" + h.first.nama + ")"
            if (i < 30) catat(baris) else catatFile(baris)
            i++
        }
        if (turun.size > 30) catat("... " + (turun.size - 30) + " aplikasi lain ada di berkas log")
        catat("Total cache sesudah: " + fmt(sesudah.values.sumOf { it.cache }))
    }

    // ---------- 3. cache eksternal ----------

    private fun ukuranKb(path: String): Long {
        val out = sh("du -sk '" + path + "' 2>/dev/null").out
        return out.trim().split(Regex("\\s+")).firstOrNull()?.toLongOrNull() ?: 0L
    }

    private fun foldersBerisi(perintahDaftar: String): List<Pair<String, Long>> {
        val dirs = sh(perintahDaftar).out.lines().filter { it.startsWith("/") }
        return dirs.map { Pair(it, ukuranKb(it)) }
            .filter { it.second > 0 }
            .sortedByDescending { it.second }
    }

    private fun catatBerkas(path: String) {
        val daftar = sh("find '" + path + "' -type f 2>/dev/null").out.lines().filter { it.isNotBlank() }
        daftar.take(300).forEach { catatFile("  - " + it) }
        if (daftar.size > 300) catatFile("  ... dan " + (daftar.size - 300) + " berkas lain")
    }

    private fun pratinjauCacheEksternal() {
        val d = foldersBerisi("ls -d /sdcard/Android/data/*/cache 2>/dev/null")
        catat("Folder yang AKAN dikosongkan: " + d.size + ", total " + fmt(d.sumOf { it.second } * 1024))
        var i = 0
        for (x in d) {
            val baris = fmt(x.second * 1024).padStart(10) + "  " + x.first
            if (i < 30) catat(baris) else catatFile(baris)
            catatBerkas(x.first)
            i++
        }
        if (d.size > 30) catat("... " + (d.size - 30) + " folder lain ada di berkas log")
    }

    private fun hapusCacheEksternal() {
        val d = foldersBerisi("ls -d /sdcard/Android/data/*/cache 2>/dev/null")
        catat("Mengosongkan " + d.size + " folder, total " + fmt(d.sumOf { it.second } * 1024))
        var i = 0
        for (x in d) {
            catatBerkas(x.first)
            sh("rm -rf '" + x.first + "'/* '" + x.first + "'/.[!.]* 2>/dev/null")
            val sisa = ukuranKb(x.first)
            val baris = "dihapus " + fmt(x.second * 1024).padStart(10) + "  " + x.first +
                (if (sisa > 0) "  (sisa " + fmt(sisa * 1024) + ")" else "")
            if (i < 30) catat(baris) else catatFile(baris)
            i++
        }
        if (d.size > 30) catat("... " + (d.size - 30) + " folder lain ada di berkas log")
    }

    // ---------- 4. log MIUI ----------

    private val folderLog = "ls -d /sdcard/MIUI/debug_log /sdcard/MIUI/.debug_log 2>/dev/null"

    private fun pratinjauLog() {
        val d = foldersBerisi(folderLog)
        if (d.isEmpty()) catat("Folder log MIUI kosong atau tidak ada, tidak ada yang akan dihapus.")
        for (x in d) {
            catat("AKAN dikosongkan: " + fmt(x.second * 1024).padStart(10) + "  " + x.first)
            catatBerkas(x.first)
        }
        catat("Buffer logcat saat ini:")
        sh("logcat -g 2>&1").out.lines().take(10).forEach { catat(it) }
    }

    private fun hapusLog() {
        val d = foldersBerisi(folderLog)
        for (x in d) {
            catatBerkas(x.first)
            sh("rm -rf '" + x.first + "'/* '" + x.first + "'/.[!.]* 2>/dev/null")
            catat("dihapus " + fmt(x.second * 1024).padStart(10) + "  " + x.first)
        }
        if (d.isEmpty()) catat("Folder log MIUI kosong atau tidak ada.")
        val r = sh("logcat -b all -c")
        catat("Buffer logcat dikosongkan, kode " + r.kode)
    }

    // ---------- 5. dexopt ----------

    private fun pratinjauDexopt() {
        val p = ambilPaket()
        if (p.isEmpty()) return
        catat("Kode aplikasi total saat ini: " + fmt(p.sumOf { it.app }))
        catat("Reset dexopt tidak menghapus berkas apa pun milikmu; hanya hasil kompilasi (oat/odex) yang dibuat ulang.")
        catat("Aplikasi dengan ukuran kode terbesar:")
        tampil(p.sortedByDescending { it.app }, 15) { it.app }
    }

    private fun hapusDexopt() {
        val sebelum = ambilPaket()
        if (sebelum.isEmpty()) return
        val a0 = sebelum.sumOf { it.app }
        catat("Kode aplikasi total sebelum: " + fmt(a0))
        catat("Menjalankan reset dexopt, mohon tunggu...")
        val r = sh("cmd package compile --reset -a")
        val baris = r.out.lines().filter { it.isNotBlank() }
        catat("Selesai, kode " + r.kode + ", " + baris.size + " baris keluaran")
        baris.take(5).forEach { catat(it) }
        baris.drop(5).forEach { catatFile(it) }
        if (r.err.isNotEmpty()) catat("[stderr] " + r.err)
        val a1 = ambilPaket().sumOf { it.app }
        catat("Kode aplikasi total sesudah: " + fmt(a1))
        catat(if (a1 <= a0) "Turun " + fmt(a0 - a1) else "Naik " + fmt(a1 - a0))
    }
}
