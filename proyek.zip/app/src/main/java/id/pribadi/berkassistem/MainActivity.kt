package id.pribadi.berkassistem

import android.app.Activity
import android.app.AlertDialog
import android.content.pm.PackageManager
import android.graphics.Typeface
import android.os.Bundle
import android.os.Environment
import android.os.StatFs
import android.text.format.Formatter
import android.widget.Button
import android.widget.LinearLayout
import android.widget.ScrollView
import android.widget.TextView
import rikka.shizuku.Shizuku
import java.util.concurrent.Executors

class MainActivity : Activity() {

    private class Aksi(
        val judul: String,
        val info: String,
        val perintah: String,
        val konfirmasi: Boolean
    )

    private val daftarAksi = listOf(
        Aksi(
            "1. Analisis penyimpanan",
            "Hanya membaca. Menampilkan ringkasan sistem dan folder terbesar yang bisa diakses. Jalankan ini dulu untuk tahu sumber pemborosan.",
            """
            echo "== Ringkasan diskstats =="
            dumpsys diskstats | cut -c1-150 | head -n 30
            echo
            echo "== Sisa ruang /data =="
            df -h /data | tail -n 1
            echo
            echo "== Android/data terbesar (MB) =="
            du -sm /sdcard/Android/data/* 2>/dev/null | sort -rn | head -n 15
            echo
            echo "== Android/obb dan MIUI (MB) =="
            du -sm /sdcard/Android/obb /sdcard/MIUI 2>/dev/null
            echo
            echo "== Folder tersembunyi di /sdcard (MB) =="
            du -sm /sdcard/.[!.]* 2>/dev/null | sort -rn | head -n 10
            """.trimIndent(),
            false
        ),
        Aksi(
            "2. Bersihkan cache semua aplikasi",
            "Menjalankan pm trim-caches. Cache aplikasi dihapus, data dan login tetap aman. Aplikasi bisa terasa sedikit lebih lambat saat dibuka pertama kali.",
            """
            pm trim-caches 999G
            echo "Cache semua aplikasi dibersihkan"
            """.trimIndent(),
            true
        ),
        Aksi(
            "3. Bersihkan cache eksternal",
            "Menghapus isi folder cache di /sdcard/Android/data/*/cache. Hanya berisi berkas sementara.",
            """
            rm -rf /sdcard/Android/data/*/cache/*
            echo "Cache eksternal dibersihkan"
            """.trimIndent(),
            true
        ),
        Aksi(
            "4. Bersihkan log",
            "Mengosongkan buffer logcat dan folder log debug MIUI di /sdcard/MIUI.",
            """
            logcat -b all -c
            rm -rf /sdcard/MIUI/debug_log/* /sdcard/MIUI/.debug_log/*
            echo "Log dibersihkan"
            """.trimIndent(),
            true
        ),
        Aksi(
            "5. Reset dexopt (hemat ruang ART)",
            "Mengembalikan hasil kompilasi aplikasi ke pengaturan bawaan dan bisa mengecilkan berkas kompilasi. Prosesnya bisa memakan beberapa menit, dan aplikasi mungkin terasa lebih lambat sampai sistem mengoptimalkan ulang saat HP diisi daya.",
            """
            cmd package compile --reset -a
            echo "Reset dexopt selesai"
            """.trimIndent(),
            true
        )
    )

    private val executor = Executors.newSingleThreadExecutor()
    private val tombolAksi = mutableListOf<Button>()

    private lateinit var scroll: ScrollView
    private lateinit var status: TextView
    private lateinit var bebasView: TextView
    private lateinit var log: TextView

    private val listenerBinder = Shizuku.OnBinderReceivedListener { runOnUiThread { segarkan() } }
    private val listenerMati = Shizuku.OnBinderDeadListener { runOnUiThread { segarkan() } }
    private val listenerIzin =
        Shizuku.OnRequestPermissionResultListener { _, _ -> runOnUiThread { segarkan() } }

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        val pad = dp(16)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(pad, dp(32), pad, pad)
        }

        status = TextView(this).apply { textSize = 16f }
        bebasView = TextView(this).apply { textSize = 14f }
        root.addView(status)
        root.addView(bebasView)

        root.addView(Button(this).apply {
            text = "Buka Shizuku"
            setOnClickListener { bukaShizuku() }
        })
        root.addView(Button(this).apply {
            text = "Beri izin Shizuku"
            setOnClickListener { mintaIzin() }
        })

        daftarAksi.forEach { aksi ->
            val tombol = Button(this).apply {
                text = aksi.judul
                setOnClickListener { klik(aksi) }
            }
            tombolAksi += tombol
            root.addView(tombol)
            root.addView(TextView(this).apply {
                text = aksi.info
                textSize = 12f
            })
        }

        log = TextView(this).apply {
            typeface = Typeface.MONOSPACE
            textSize = 12f
            setTextIsSelectable(true)
            setPadding(0, dp(16), 0, 0)
        }
        root.addView(log)

        scroll = ScrollView(this).apply { addView(root) }
        setContentView(scroll)

        Shizuku.addBinderReceivedListenerSticky(listenerBinder)
        Shizuku.addBinderDeadListener(listenerMati)
        Shizuku.addRequestPermissionResultListener(listenerIzin)
        segarkan()
    }

    override fun onResume() {
        super.onResume()
        segarkan()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(listenerBinder)
        Shizuku.removeBinderDeadListener(listenerMati)
        Shizuku.removeRequestPermissionResultListener(listenerIzin)
        executor.shutdown()
        super.onDestroy()
    }

    private fun dp(nilai: Int): Int = (nilai * resources.displayMetrics.density).toInt()

    private fun tulis(teks: String) {
        log.append(teks + "\n")
        scroll.post { scroll.fullScroll(ScrollView.FOCUS_DOWN) }
    }

    private fun bebasByte(): Long =
        StatFs(Environment.getDataDirectory().path).availableBytes

    private fun format(byte: Long): String = Formatter.formatFileSize(this, byte)

    private fun siap(): Boolean = try {
        Shizuku.pingBinder() &&
            Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    private fun segarkan() {
        status.text = try {
            when {
                !Shizuku.pingBinder() -> "Shizuku: belum berjalan"
                Shizuku.checkSelfPermission() != PackageManager.PERMISSION_GRANTED ->
                    "Shizuku: berjalan, izin belum diberikan"
                else -> "Shizuku: siap"
            }
        } catch (e: Throwable) {
            "Shizuku: tidak tersedia"
        }
        bebasView.text = "Ruang bebas: " + format(bebasByte())
    }

    private fun bukaShizuku() {
        val intent = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        if (intent == null) {
            tulis("Aplikasi Shizuku belum terpasang. Pasang dulu dari GitHub atau Play Store.")
        } else {
            startActivity(intent)
        }
    }

    private fun mintaIzin() {
        try {
            if (!Shizuku.pingBinder()) {
                tulis("Shizuku belum berjalan. Buka aplikasi Shizuku lalu mulai lewat Wireless debugging.")
                return
            }
            if (Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED) {
                tulis("Izin sudah diberikan.")
                return
            }
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                tulis("Izin ditolak permanen. Aktifkan lewat aplikasi Shizuku, menu izin aplikasi.")
                return
            }
            Shizuku.requestPermission(100)
        } catch (e: Throwable) {
            tulis("Gagal meminta izin: " + e.message)
        }
    }

    private fun klik(aksi: Aksi) {
        if (!siap()) {
            tulis("Shizuku belum siap. Pastikan Shizuku berjalan dan izin sudah diberikan.")
            return
        }
        if (aksi.konfirmasi) {
            AlertDialog.Builder(this)
                .setTitle(aksi.judul)
                .setMessage(aksi.info + "\n\nLanjutkan?")
                .setPositiveButton("Jalankan") { _, _ -> jalankan(aksi) }
                .setNegativeButton("Batal", null)
                .show()
        } else {
            jalankan(aksi)
        }
    }

    private fun aturSibuk(sibuk: Boolean) {
        tombolAksi.forEach { it.isEnabled = !sibuk }
    }

    private fun jalankan(aksi: Aksi) {
        aturSibuk(true)
        val sebelum = bebasByte()
        tulis("\n> " + aksi.judul)
        executor.execute {
            val hasil = try {
                Shell.jalankan(aksi.perintah)
            } catch (e: Throwable) {
                val sebab = e.cause ?: e
                Shell.Hasil(-1, "", sebab.javaClass.simpleName + ": " + sebab.message)
            }
            val sesudah = bebasByte()
            runOnUiThread {
                if (hasil.out.isNotEmpty()) tulis(hasil.out)
                if (hasil.err.isNotEmpty()) tulis("[stderr] " + hasil.err)
                tulis("Kode keluar: " + hasil.kode)
                tulis("Ruang bebas: " + format(sebelum) + " -> " + format(sesudah))
                aturSibuk(false)
                segarkan()
            }
        }
    }
}
